package application;

public class Forecast {

	public String date;
	public double temp;
	public Forecast(String d, double t){
		date = d;
		temp = t;
	}
}
